<template>
  <div>
    <p>{{msg}}</p>
    <hr>
    <p>{{msgWithPrefix}}</p>
  </div>
</template>

<script>
export default {
  name: 'cmp2',
  computed: {
    msg() {
      return this.$store.state.msgFrom1
    },
    msgWithPrefix() {
      return this.$store.getters['getMsgFrom1WithPrefix']
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
