<template>
  <div>
    <h1>Hi I'm cmp1</h1>
    <p>Here's what I would like to tell cmp2 using VUEX:</p>
    <input type="text" v-model="msgFrom1">
    <hr>
    <button @click="commitHello">Presents commits in VUEX</button>
    <button @click="getStupidMessage">Presents actions in VUEX</button>
  </div>
</template>

<script>
export default {
  name: 'cmp1',
  computed: {
    msgFrom1: {
      get() {
        return this.$store.state.msgFrom1
      },
      set(val) {
        this.$store.commit('setMsgFrom1', val)
      }
    }
  },
  methods: {
    commitHello() {
      this.$store.commit('setMsgFrom1', 'hello!')
    },
    getStupidMessage() {
      this.$store.dispatch('fetchStupidMessage')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
