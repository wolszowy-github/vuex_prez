<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <cmp1 />
    <cmp2 />
  </div>
</template>

<script>
import cmp1 from './components/cmp1.vue'
import cmp2 from './components/cmp2.vue'

export default {
  name: 'app',
  components: {
    cmp1,
    cmp2
  }
}
</script>

<style lang="scss">

</style>
