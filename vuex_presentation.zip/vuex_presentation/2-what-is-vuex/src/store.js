import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    msgFrom1: 'stored msg'
  },
  getters: {
    getMsgFrom1WithPrefix(state) {
      return `Cmp1 says: ${state.msgFrom1}`
    }
  },
  mutations: {
    setMsgFrom1(state, newVal) {
      state.msgFrom1 = newVal
    } 
  },
  actions: {
    fetchStupidMessage({commit}) {
      axios.get('https://dummy-91ded.firebaseio.com/message.json')
      .then(response => {
        commit('setMsgFrom1', response.data)
      })
    }
  }
})
