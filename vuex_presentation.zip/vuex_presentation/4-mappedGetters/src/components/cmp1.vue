<template>
  <div>
    <p>{{getSaladAndCheese}}</p>
    <p>{{customSalad}}</p>
  </div>
</template>

<script>
import { mapGetters } from 'vuex'

export default {
  name: 'cmp1',
  computed: {
    ...mapGetters(['getSaladAndCheese']),
    customSalad() {
      return this.$store.getters['getSaladWithCheeseAndSth']('i z kiełbasą')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
