import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    test: 'Sałata',
  },
  getters: {
    getSaladAndCheese(state) {
      return state.test + ' z serem'
    },
    getSaladWithCheeseAndSth (state, getters) {
      return (sth) => {
        return getters.getSaladAndCheese + ' ' + sth
      }
    }
  },
  mutations: {

  },
  actions: {

  }
})
