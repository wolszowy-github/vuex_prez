<template>
  <div>
    <h1>Hi I'm cmp1</h1>
    <p>Here's what I would like to tell cmp2:</p>
    <input @input="sendMsg" type="text" v-model="msgFrom1">
  </div>
</template>

<script>
export default {
  name: 'cmp1',
  props: {
    msg2: String
  },
  data() {
    return {
      msgFrom1: ''
    }
  },
  methods: {
    sendMsg() {
      this.$emit('sendMsg1', this.msgFrom1)
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
