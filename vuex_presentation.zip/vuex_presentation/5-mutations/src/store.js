import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    someNumber: 0,
  },
  getters: {

  },
  mutations: {
    addOne: state => {
      state.someNumber++
    },
    addGivenNumber: (state, payload) => {
      state.someNumber += payload 
    },
    addGivenNumberObjWay: (state, payload) => {
      state.someNumber += payload.number
    }
  },
  actions: {

  }
})
