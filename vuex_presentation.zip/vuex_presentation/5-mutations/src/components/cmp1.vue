<template>
  <div>
    <h2>This is some number:</h2>
    <p>{{someNum}}</p>
    <button @click="theBasicWay">Add one the basic way</button>
    <button @click="addOne">Add one</button>
    <button @click="addGivenNumber(5)">Add given number</button>
    <button @click="theObjectWay(3)">Add given number the object way</button>
  </div>
</template>

<script>
import { mapMutations } from 'vuex'

export default {
  name: 'cmp1',
  computed: {
    someNum() {
      return this.$store.state.someNumber
    }
  },
  methods: {
    theBasicWay() {
      this.$store.commit('addOne')
    },
    theObjectWay(givenNum) {
      this.$store.commit({type: 'addGivenNumberObjWay', number: givenNum})
    },
    ...mapMutations(['addOne', 'addGivenNumber'])
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
