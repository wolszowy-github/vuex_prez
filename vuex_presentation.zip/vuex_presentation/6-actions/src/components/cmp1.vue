<template>
  <div>
    <h2>This is some message:</h2>
    <p>{{someMessage}}</p>
    <h3 v-if="bark">Woof!</h3>
    <button @click="fetchMessage">Show me the message!</button>
    <button @click="fetchMessageThenBark">fetchMessageThenBark</button>
    <button @click="setMessage(''), bark = false">Reset</button>
  </div>
</template>

<script>
import { mapActions, mapMutations } from 'vuex'

export default {
  name: 'cmp1',
  data(){
    return {
      bark: false
    }
  },
  computed: {
    someMessage() {
      return this.$store.state.someMessage
    }
  },
  methods: {
    ...mapMutations(['setMessage']),
    ...mapActions(['fetchMessage']),
    fetchMessageThenBark() {
      this.fetchMessage().then(() => {
        this.bark = true
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
