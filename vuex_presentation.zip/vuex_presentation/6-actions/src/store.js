import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    someMessage: '',
  },
  getters: {

  },
  mutations: {
    setMessage: (state, newMessage) => {
      state.someMessage = newMessage
    }
  },
  actions: {
    fetchMessage: context => {
     return axios.get('https://dummy-91ded.firebaseio.com/message.json')
        .then(response => {
          context.commit('setMessage', response.data)
          console.log('this is context of an action', context)
        })
    }
  }
})
