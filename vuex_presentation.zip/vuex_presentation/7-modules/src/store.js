import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const exampleOne = {
  state: {
    msg: 'module a'
  },
  mutations: {
    setMsg(state) {
      state.msg = 'module a changed'
    }
  },
  actions: {

  }
}

const exampleTwo = {
  namespaced: true,
  state: {
    msg: 'module b'
  },
  mutations: {
    setMsg(state) {
      state.msg = 'module b changed'
    }
  },
  actions: {

  }
}

export default new Vuex.Store({
  state: {
    someMessage: 'message from root',
  },
  modules: {
    a: exampleOne,
    b: exampleTwo
  }
})
