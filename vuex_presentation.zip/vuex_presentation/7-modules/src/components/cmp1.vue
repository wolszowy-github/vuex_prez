<template>
  <div>
    <h2>This is some message:</h2>
    <p>{{someMessage}}</p>
    <p>{{moduleAMessage}}</p>
    <p>{{moduleBMessage}}</p>
    <button @click="setMsg">Change modules state</button>
    <button @click="mutateNamespacedModule">Mutate namespaced module</button>
  </div>
</template>

<script>
import { mapActions, mapMutations } from 'vuex'

export default {
  name: 'cmp1',
  computed: {
    someMessage() {
      return this.$store.state.someMessage
    },
    moduleAMessage() {
      return this.$store.state.a.msg
    },
    moduleBMessage() {
      return this.$store.state.b.msg
    }
  },
  methods: {
    ...mapMutations(['setMsg']),
    mutateNamespacedModule() {
      this.$store.commit('b/setMsg')
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
