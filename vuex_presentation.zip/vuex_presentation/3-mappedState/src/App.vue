<template>
  <div id="app">
    <img alt="Vue logo" src="./assets/logo.png">
    <cmp1 />
  </div>
</template>

<script>
import cmp1 from './components/cmp1.vue'

export default {
  name: 'app',
  components: {
    cmp1
  }
}
</script>

<style lang="scss">

</style>
