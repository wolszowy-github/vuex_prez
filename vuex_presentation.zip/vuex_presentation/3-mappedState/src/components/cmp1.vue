<template>
  <div>
    <p>{{dummy}}</p>
    <p>{{dummyMethod}}</p>
    <p>{{aliasForDummy}}</p>
    <p>{{dummyWithSuffix}}</p>
  </div>
</template>

<script>
import { mapState } from 'vuex'

export default {
  name: 'cmp1',
  data: () => {
    return {
      suffix: 'MNIAM'
    }
  },
  computed: {
    ...mapState(['dummy']),
    ...mapState({
      dummyMethod: state => state.dummy
    }),
    ...mapState({
      aliasForDummy: 'dummy'
    }),
    ...mapState({
      dummyWithSuffix(state) {
        return state.dummy + this.suffix
      }
    })
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>
